# filewatcher

This is a helper package to monitor files. You can use
[Cyberinfy-filewatcher](https://github.com/cyberinfy/Tools/blob/master/filewatcher/filewatcher_usage.py)
to write your content.


# Check out a usage example with explaination at 
[Cyberinfy-filewatcher filewatcher_usage.py](https://github.com/cyberinfy/Tools/blob/master/filewatcher/filewatcher_usage.py)


